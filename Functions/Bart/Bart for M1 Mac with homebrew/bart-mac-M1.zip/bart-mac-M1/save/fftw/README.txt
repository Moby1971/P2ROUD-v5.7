Saves FFT wisdom.
